# MotoCam 1.0

Motosiklet sürüşü sırasında telefonu yol kamerası gibi kullanmak için hazırlanmış Android uygulaması.

## Özellikler

- Arka kamera canlı görüntü
- 1080p tercihli kayıt, cihaz gerekirse 720p'ye düşer
- CameraX video stabilizasyonu
- Stabilizasyon desteklenmeyen telefonda otomatik güvenli geri dönüş
- “Başla” / “Dur” Türkçe sesli komut
- Bluetooth interkom mikrofonunu kullanmaya çalışma (Android 12+)
- Kayıt sayacı
- Ekranı açık tutma
- Kayıtları `Galeri > Movies > MotoCam` klasörüne kaydetme
- Uygulamadan galeriye hızlı geçiş
- Dikey veya yatay telefon kullanımına uyum

## Neden video sessiz?

MotoCam 1.0'da sesli komut sistemi sürekli mikrofon dinler.
Android telefonların önemli bir kısmında aynı mikrofonu aynı anda hem
video ses kaydı hem SpeechRecognizer için kullanmak mümkün değildir.
Bu yüzden güvenilir “Başla / Dur” kontrolü için yol videosu sessiz kaydedilir.

## Telefon gereksinimi

- Android 8.0 veya üstü
- Kamera
- Mikrofon
- Stabilizasyon donanımı/yazılımı varsa MotoCam bunu kullanır
- Bluetooth interkom Android tarafından mikrofon cihazı olarak sunuluyorsa
  sesli komut için kullanılabilir

## Android Studio ile APK

1. Projeyi Android Studio ile aç.
2. Gradle Sync tamamlanınca:
   `Build > Build App Bundle(s) / APK(s) > Build APK(s)`
3. APK:
   `app/build/outputs/apk/debug/app-debug.apk`

## GitHub ile otomatik APK

Projede `.github/workflows/build-apk.yml` hazırdır.

1. Projeyi GitHub reposuna yükle.
2. GitHub > Actions > `Build MotoCam APK`
3. `Run workflow`
4. İş bitince `MotoCam-debug-apk` artifact'ını indir.
5. İçindeki `app-debug.apk` dosyasını Android telefona kur.

## Kurulumda Android uyarısı

Debug APK Play Store'dan gelmediği için Android “bilinmeyen uygulama yükleme”
izni isteyebilir. APK'yı açtığın dosya yöneticisi/tarayıcı için bu izni
bir kez vermen gerekir.

## Güvenlik

Sürüş sırasında ekrana dokunma. Telefonu sağlam bir motosiklet tutucusunda kullan.
Kayıt ve sesli komutları hareket etmeden önce test et.
