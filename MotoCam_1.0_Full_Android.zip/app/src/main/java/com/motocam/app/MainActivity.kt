package com.motocam.app

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.motocam.app.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var provider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var voiceWanted = true

    private val uiHandler = Handler(Looper.getMainLooper())
    private var recordingStartMs = 0L
    private var timerRunning = false

    private var stabilizationRequested = true
    private var stabilizationActuallyEnabled = false

    private val timerRunnable = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            val elapsed = System.currentTimeMillis() - recordingStartMs
            val h = TimeUnit.MILLISECONDS.toHours(elapsed)
            val m = TimeUnit.MILLISECONDS.toMinutes(elapsed) % 60
            val s = TimeUnit.MILLISECONDS.toSeconds(elapsed) % 60
            binding.tvTimer.text = String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
            uiHandler.postDelayed(this, 500)
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasCameraPermission()) {
                bindCamera()
            } else {
                toast("Kamera izni olmadan MotoCam çalışamaz.")
            }

            if (hasMicPermission() && binding.switchVoice.isChecked) {
                startVoiceControl()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        voiceWanted = binding.switchVoice.isChecked
        stabilizationRequested = binding.switchStabilization.isChecked
        applyKeepScreen(binding.switchKeepScreen.isChecked)

        binding.btnRecord.setOnClickListener {
            if (activeRecording == null) startRecording() else stopRecording()
        }

        binding.btnGallery.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "video/*"
                data = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            try {
                startActivity(intent)
            } catch (_: Exception) {
                toast("Galeri uygulaması açılamadı.")
            }
        }

        binding.switchVoice.setOnCheckedChangeListener { _, enabled ->
            voiceWanted = enabled
            if (enabled) {
                if (hasMicPermission()) startVoiceControl() else requestPermissions()
            } else {
                stopVoiceControl()
                binding.tvVoice.text = "Sesli komut: kapalı"
            }
        }

        binding.switchStabilization.setOnCheckedChangeListener { _, enabled ->
            stabilizationRequested = enabled
            if (activeRecording == null && hasCameraPermission()) {
                bindCamera()
            } else if (activeRecording != null) {
                toast("Stabilizasyon ayarı bir sonraki kayıtta uygulanır.")
            }
        }

        binding.switchKeepScreen.setOnCheckedChangeListener { _, enabled ->
            applyKeepScreen(enabled)
        }

        requestPermissions()
    }

    private fun applyKeepScreen(enabled: Boolean) {
        if (enabled) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun requestPermissions() {
        val needed = mutableListOf<String>()
        if (!hasCameraPermission()) needed += Manifest.permission.CAMERA
        if (!hasMicPermission()) needed += Manifest.permission.RECORD_AUDIO

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
        }

        if (needed.isEmpty()) {
            bindCamera()
            if (binding.switchVoice.isChecked) startVoiceControl()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            bindCameraInternal(stabilizationRequested)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraInternal(tryStabilization: Boolean) {
        val p = provider ?: return

        try {
            p.unbindAll()

            val previewBuilder = Preview.Builder()
            if (tryStabilization) {
                previewBuilder.setPreviewStabilizationEnabled(true)
            }
            val preview = previewBuilder.build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(Quality.FHD, Quality.HD),
                        androidx.camera.video.FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)
                    )
                )
                .build()

            val videoBuilder = VideoCapture.Builder(recorder)
            if (tryStabilization) {
                videoBuilder.setVideoStabilizationEnabled(true)
            }

            val capture = videoBuilder.build()
            videoCapture = capture

            p.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                capture
            )

            stabilizationActuallyEnabled = tryStabilization
            binding.tvStatus.text = "Kamera hazır"
            binding.tvStabilization.text =
                if (stabilizationActuallyEnabled) "Stabilizasyon: AÇIK"
                else "Stabilizasyon: KAPALI"

        } catch (e: Exception) {
            if (tryStabilization) {
                stabilizationActuallyEnabled = false
                binding.tvStabilization.text = "Stabilizasyon desteklenmedi, kapatıldı"
                bindCameraInternal(false)
            } else {
                binding.tvStatus.text = "Kamera açılamadı"
                toast("Kamera başlatılamadı: ${e.message ?: "bilinmeyen hata"}")
            }
        }
    }

    private fun startRecording() {
        val capture = videoCapture ?: run {
            toast("Kamera henüz hazır değil.")
            return
        }

        val filename = "MotoCam_" + SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.getDefault()
        ).format(System.currentTimeMillis())

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, filename)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MotoCam")
            }
        }

        val output = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        // Audio is intentionally NOT enabled.
        // Continuous voice command recognition and video audio recording compete
        // for microphone access on many Android devices.
        activeRecording = capture.output
            .prepareRecording(this, output)
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> onRecordingStarted()
                    is VideoRecordEvent.Finalize -> onRecordingFinalized(event)
                }
            }
    }

    private fun onRecordingStarted() {
        recordingStartMs = System.currentTimeMillis()
        timerRunning = true
        uiHandler.removeCallbacks(timerRunnable)
        uiHandler.post(timerRunnable)

        binding.btnRecord.text = "KAYDI DURDUR"
        binding.tvStatus.text = "● KAYIT"
        binding.switchStabilization.isEnabled = false
    }

    private fun onRecordingFinalized(event: VideoRecordEvent.Finalize) {
        activeRecording = null
        timerRunning = false
        uiHandler.removeCallbacks(timerRunnable)

        binding.btnRecord.text = "KAYDI BAŞLAT"
        binding.tvTimer.text = "00:00:00"
        binding.switchStabilization.isEnabled = true

        if (event.hasError()) {
            binding.tvStatus.text = "Kayıt hatası"
            toast("Video kaydedilemedi. Hata kodu: ${event.error}")
        } else {
            binding.tvStatus.text = "Video kaydedildi"
            toast("Video Galeri > Movies > MotoCam klasörüne kaydedildi.")
        }
    }

    private fun stopRecording() {
        activeRecording?.stop()
    }

    private fun startVoiceControl() {
        if (!voiceWanted || !hasMicPermission()) return

        tryRouteBluetoothMic()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            binding.tvVoice.text = "Sesli tanıma bu telefonda desteklenmiyor"
            return
        }

        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    binding.tvVoice.text = "Sesli komut: dinliyor"
                }

                override fun onResults(results: Bundle?) {
                    handleVoiceResults(results)
                    restartVoiceSoon()
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    handleVoiceResults(partialResults)
                }

                override fun onError(error: Int) {
                    if (voiceWanted) restartVoiceSoon(650)
                }

                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
        }

        listenOnce()
    }

    private fun handleVoiceResults(results: Bundle?) {
        val texts = results
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            .orEmpty()

        val normalized = texts
            .joinToString(" ")
            .lowercase(Locale("tr", "TR"))

        if (normalized.isNotBlank()) {
            binding.tvVoice.text = "Duyuldu: ${texts.firstOrNull().orEmpty()}"
        }

        when {
            normalized.contains("başla") ||
                normalized.contains("basla") ||
                normalized.contains("kayıt başla") ||
                normalized.contains("kayit basla") -> {
                if (activeRecording == null) {
                    startRecording()
                    binding.tvVoice.text = "Komut alındı: BAŞLA"
                }
            }

            normalized.contains("dur") ||
                normalized.contains("kaydı durdur") ||
                normalized.contains("kaydi durdur") -> {
                if (activeRecording != null) {
                    stopRecording()
                    binding.tvVoice.text = "Komut alındı: DUR"
                }
            }
        }
    }

    private fun listenOnce() {
        if (!voiceWanted || !binding.switchVoice.isChecked) return

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }

        try {
            speechRecognizer?.cancel()
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            restartVoiceSoon(800)
        }
    }

    private fun restartVoiceSoon(delayMs: Long = 400L) {
        if (!voiceWanted) return
        binding.root.postDelayed({
            if (voiceWanted) listenOnce()
        }, delayMs)
    }

    private fun stopVoiceControl() {
        speechRecognizer?.cancel()
    }

    private fun tryRouteBluetoothMic() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val audio = getSystemService(AudioManager::class.java)
        val bt = audio.availableCommunicationDevices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
        }

        if (bt != null) {
            audio.setCommunicationDevice(bt)
            binding.tvVoice.text = "Bluetooth interkom mikrofonu seçildi"
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        super.onPause()
        // MotoCam is designed to run visibly while mounted on the motorcycle.
        // Camera recording is not forced into background due to Android camera restrictions.
    }

    override fun onDestroy() {
        timerRunning = false
        uiHandler.removeCallbacks(timerRunnable)
        activeRecording?.stop()
        speechRecognizer?.destroy()
        speechRecognizer = null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                getSystemService(AudioManager::class.java).clearCommunicationDevice()
            } catch (_: Exception) {
            }
        }

        super.onDestroy()
    }
}
